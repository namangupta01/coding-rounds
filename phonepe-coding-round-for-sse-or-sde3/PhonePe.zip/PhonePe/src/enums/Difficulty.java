package enums;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
