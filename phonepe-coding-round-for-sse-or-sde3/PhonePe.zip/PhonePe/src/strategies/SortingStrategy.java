package strategies;

public interface SortingStrategy {
}
