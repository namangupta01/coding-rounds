package strategies;

public interface RecommendationStrategy {

}
