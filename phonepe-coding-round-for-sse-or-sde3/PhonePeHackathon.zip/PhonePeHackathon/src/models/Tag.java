package models;

public class Tag {
    private String name;

    public Tag(String tagName) {
        this.name = tagName;
    }

    public String getName() {
        return name;
    }
}
