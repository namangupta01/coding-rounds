package models;

public class Publisher {
}
