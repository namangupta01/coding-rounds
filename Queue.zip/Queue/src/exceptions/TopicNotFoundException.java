package exceptions;

public class TopicNotFoundException extends Exception {
}
